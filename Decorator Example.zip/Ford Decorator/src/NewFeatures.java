
public class NewFeatures extends FordCarFeatureDecorator{

	NewFeatures(FordCar typeOfCar) {
		super(typeOfCar);
	}
	
	public void CruiseControl() {
		typeOfCar.CruiseControl();
		System.out.println("Adaptive Cruise Control Added ");
		
	}
	
	public void Automatictransmission(){
		typeOfCar.Automatictransmission();
		System.out.println("10-Speed Rear-Drive Transmission Added");
	}
	
	public void BluetoothConnectivity(){
		typeOfCar.BluetoothConnectivity();
		System.out.println("High Quality Streaming Added");
	}
	
	

}
