
public class Driver {
	public static void main(String args[]){
	  //Older version 
		FordCar oldVerExplorer=new Explorer();
		FordCar oldVerFocus=new Focus();
	  //Newer version 	
		FordCar newVerExplorer=new NewFeatures(new Explorer());
		FordCar newVerFocus=new NewFeatures(new Focus());
	
		System.out.println("This is the older explore fearuers");
		oldVerExplorer.Automatictransmission();
		oldVerExplorer.BluetoothConnectivity();
		oldVerExplorer.CruiseControl();
		
		System.out.println("");
		
		System.out.println("This is the newer explore fearuers");
		newVerExplorer.Automatictransmission();
		
		System.out.println("");
		
		newVerExplorer.BluetoothConnectivity();
		
		System.out.println("");
		
		newVerExplorer.CruiseControl();
		
	}	
}
