
public interface FordCar {

	public void  CruiseControl();
	public void Automatictransmission();
	public void BluetoothConnectivity();
	
}
