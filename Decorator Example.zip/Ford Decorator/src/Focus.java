
public class Focus implements FordCar {

	@Override
	public void CruiseControl() {
		System.out.println("Focus Cruise Control Feature");	
		
	}

	@Override
	public void Automatictransmission() {
		System.out.println("Focus Automatic Transmission Feature");
		
	}

	@Override
	public void BluetoothConnectivity() {
		System.out.println("Explorer Automatic Transmision Feature");
		
	}
   
}
