
public class FordCarFeatureDecorator implements FordCar{
     FordCar typeOfCar;
     
     FordCarFeatureDecorator(FordCar typeOfCar){
    	 this.typeOfCar=typeOfCar;
     }


	public void CruiseControl() {
		typeOfCar.CruiseControl();
		
	}

	@Override
	public void Automatictransmission() {
		typeOfCar.Automatictransmission();
		
	}

	@Override
	public void BluetoothConnectivity() {
		typeOfCar.BluetoothConnectivity();
		
	}
     
     
}
