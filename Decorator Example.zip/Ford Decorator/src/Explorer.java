
public class Explorer implements FordCar {

	@Override
	public void CruiseControl() {
		System.out.println("Explorer Cruise Control Feature");	
	}

	@Override
	public void Automatictransmission() {
		System.out.println("Explorer Automatic Transmission Feature");
		
	}

	@Override
	public void BluetoothConnectivity() {
		System.out.println("Explorer Automatic Transmision Feature");
		
	}

}
